package parser;

public abstract class Operator extends PascalSyntax{
    //I guess this is it... :)
    Operator(int n) {
        super(n);
    }
}
