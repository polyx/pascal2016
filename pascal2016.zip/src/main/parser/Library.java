package parser;

public class Library {
}
